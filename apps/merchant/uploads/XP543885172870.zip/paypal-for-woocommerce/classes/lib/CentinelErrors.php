<?php
	 
	 define("CENTINEL_ERROR_CODE_8000", "8000");
     define("CENTINEL_ERROR_CODE_8000_DESC", "Protocol Not Recogonized, must be http:// or https://");
	 define("CENTINEL_ERROR_CODE_8010", "8010");
     define("CENTINEL_ERROR_CODE_8010_DESC", "Unable to Communicate with MAPS Server");
	 define("CENTINEL_ERROR_CODE_8020", "8020");
     define("CENTINEL_ERROR_CODE_8020_DESC", "Error Parsing XML Response");
	 define("CENTINEL_ERROR_CODE_8030", "8030");
     define("CENTINEL_ERROR_CODE_8030_DESC", "Communication Timeout Encountered");

	 define("CENTINEL_ERROR_CODE_8090", "8090");
     define("CENTINEL_ERROR_CODE_8090_DESC", "Error Parsing Payload");
	 define("CENTINEL_ERROR_CODE_8091", "8091");
     define("CENTINEL_ERROR_CODE_8091_DESC", "Invalid Payload Hash");
?>
